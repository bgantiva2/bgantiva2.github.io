﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adventure_Game_1
{
    class Items
    {
        public string Description;
        private string items;

        public string GetItems()
        {
            return items;
        }

        public void SetItems(string value)
        {
            items = value;
        }

        public void ShowItems() { }
        public void ShowDescription() { }

    }
}
