﻿using System;
using static System.Console;

namespace Adventure_Game_1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Welcome to the world of Omicron Persei 8");
            ReadLine();
            WriteLine("To walk down the street Press enter");
            ReadLine();
            WriteLine("You come accross a person and he says, Hey what's up" );
            ReadLine();
            WriteLine("Press enter to say hey");
            ReadLine();
            WriteLine("He takes you to a dark place where he starts to explaining that you need to go to a hospital to pick up his mom since you owe him a favor");
            ReadLine();
            WriteLine("Press enter to recieve the infromation about the location of the hospital");
            ReadLine();
            WriteLine("He gives you the info and you start reading it");
            ReadLine();
            WriteLine("Press enter to walk out of the dark place and to proceed to the hospital that is 5 miles away");
            ReadLine();
            WriteLine("As you start walking, you find 100 dollars on the floor. Press enter to pick them up");
            ReadLine();
            WriteLine("As you picked them up, there is a guy that goes to you and trys to take it from you");
            ReadLine();
            WriteLine("Press enter to start running from him");
            ReadLine();
            WriteLine("You got away from him, but you ran the other direction of the hospital, so now you have to walk more now");
            ReadLine();
            WriteLine("Press enter to call a cab since you found 100 dollars on the floor" );
            ReadLine();
            WriteLine("The cab gets there and you enter");
            ReadLine();
            WriteLine("You arrive at the hospital and the mother is outside waiting");
            ReadLine();
            WriteLine("You tell her that her son sent you, but she starts to scream at you. Press enter to Tell her to calm down");
            ReadLine();
            WriteLine("She looks at you like your crazy. then ya'll take the cab back to the son's place");
            ReadLine();
            WriteLine("Press enter to give the cab mone for the trip");
            ReadLine();
            WriteLine("Once she enters, the son comes out and tells you that he needs another favor");
            ReadLine();
            WriteLine("Press enter to decline");
            ReadLine();
            WriteLine("You walk away and you find a huge bag  with some new Jordans on the floor and with a million dollors in it. Press enter to pick it up");
            ReadLine();
            WriteLine("You get so happy that you go to buy the things you ever wanted and you ended finding the love of your life");
            ReadLine();
            WriteLine("You wake up");
            ReadLine();
            WriteLine("The happiness was just a dream and you relized that your life is actually horriable");
            ReadLine();
        }
    }
}
