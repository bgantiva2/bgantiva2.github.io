﻿using System;

namespace Study_Application
{
    class Program
        //Brandon Gantiva
        //10-25-20
        //credits to myself, Brandon Gantiva
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the study app");
            Console.WriteLine("function / method argument: Variable that finds the function");
            Console.WriteLine("function / method parameter: A variable found in a function definition");
            Console.WriteLine("array: a DATA structure of a collection of elements or values");
            Console.WriteLine("instance: A specific variation of an object");
            Console.WriteLine("array element: Values or variables");
            Console.WriteLine("array index number: It's the location of an item");
            Console.WriteLine("private: Only that class has access to the variable");
            Console.WriteLine("public: every class has access to the variable");
            Console.WriteLine("static: Belongs to a class not a specific instance");
            Console.WriteLine("void: a result of a function that retuns to normal");
            Console.WriteLine("conditional statement: To state whether true or false");
            Console.WriteLine("increment: The process of increasing or decreasing a number value");
            Console.WriteLine("while loop: to repeat a section of code");
            Console.WriteLine("for loop: a specific of times to reapeat a code");
            Console.WriteLine("switch: change the control of the flow of the program");
            Console.ReadLine();
        }

        private static void Main1()
        {
            Console.Title = "The Study Application";
            Console.WindowHeight = Console.LargestWindowHeight - 20;
            Header();
        }
        private static void Header()
        {
            string header = @"
The Study Application";
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(header);
            Console.ResetColor();



        }
    }
}
