﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Study_Application
{
    class Study_app
    {
    }
}
