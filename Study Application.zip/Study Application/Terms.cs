﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Study_Application
{
    class Terms
    {
        public string TermnText;
        public string CorrectTerm;

        public void ShowTerm() { }
        public void CheckTerm() { }
    }
}
