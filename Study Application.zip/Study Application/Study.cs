﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Study_Application
{
    class Study
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            object p = game.Start();
        }

        private class Game
        {
            internal object Start()
            {
                throw new NotImplementedException();
            }
        }
    }
}
